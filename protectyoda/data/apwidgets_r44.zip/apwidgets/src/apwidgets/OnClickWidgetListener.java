package apwidgets;

public interface OnClickWidgetListener {
	public void onClickWidget(APWidget widget);
}
